from django.conf import settings
from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import include, path, re_path
from django.views.static import serve
from store.sitemaps import ProductSitemap, CategorySitemap
from store.views import robots_txt

admin.site.site_header = "RH Rahul Vai Shop - Admin"
admin.site.site_title = "RH Shop Admin"
admin.site.index_title = "দোকান ম্যানেজমেন্ট"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")),
    path("sitemap.xml", sitemap, {"sitemaps": {"products": ProductSitemap, "categories": CategorySitemap}}),
    path("robots.txt", robots_txt),
    re_path(r"^media/(?P<path>.*)$", serve, {"document_root": settings.MEDIA_ROOT}),
    path("", include("store.urls")),
]
