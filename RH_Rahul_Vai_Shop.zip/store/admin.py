from django.contrib import admin
from django.db import transaction
from django.db.models import F
from django.utils.html import format_html

from .models import (Banner, Category, Color, Coupon, DeliveryZone, Order, OrderItem, Product,
                     ProductImage, Profile, Size, Wishlist)


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("thumb", "name", "category", "price", "discount_price", "stock", "is_active",
                    "is_new_arrival", "is_featured", "sold_count")
    list_editable = ("price", "discount_price", "stock", "is_active", "is_new_arrival", "is_featured")
    list_filter = ("category", "is_active", "is_new_arrival", "is_featured")
    search_fields = ("name", "description")
    filter_horizontal = ("sizes", "colors")
    prepopulated_fields = {}
    inlines = [ProductImageInline]
    list_per_page = 30

    @admin.display(description="ছবি")
    def thumb(self, obj):
        return format_html('<img src="{}" style="height:45px;border-radius:4px">', obj.image.url) if obj.image else "-"


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    search_fields = ("name",)


admin.site.register(Size)
admin.site.register(Color)
admin.site.register(DeliveryZone)


@admin.register(Banner)
class BannerAdmin(admin.ModelAdmin):
    list_display = ("title", "is_offer", "is_active", "order")
    list_editable = ("is_offer", "is_active", "order")


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ("code", "discount_type", "value", "min_order", "valid_to", "used_count", "usage_limit", "is_active")
    list_editable = ("is_active",)


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("product", "product_name", "price", "quantity", "size", "color")
    can_delete = False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("order_number", "name", "phone", "total", "payment_method", "payment_status",
                    "transaction_id", "status", "created_at")
    list_editable = ("status", "payment_status")
    list_filter = ("status", "payment_status", "payment_method", "created_at")
    search_fields = ("order_number", "name", "phone", "transaction_id")
    readonly_fields = ("order_number", "user", "subtotal", "discount", "delivery_charge", "total", "coupon")
    inlines = [OrderItemInline]
    date_hierarchy = "created_at"
    actions = ["mark_processing", "mark_shipped", "mark_delivered", "mark_paid", "cancel_orders"]

    @admin.action(description="Mark as Processing")
    def mark_processing(self, request, qs):
        qs.update(status="processing")

    @admin.action(description="Mark as Shipped")
    def mark_shipped(self, request, qs):
        qs.update(status="shipped")

    @admin.action(description="Mark as Delivered (COD হলে Paid হবে)")
    def mark_delivered(self, request, qs):
        qs.update(status="delivered")
        qs.filter(payment_method="cod").update(payment_status="paid")

    @admin.action(description="Mark Payment as Paid")
    def mark_paid(self, request, qs):
        qs.update(payment_status="paid")

    @admin.action(description="Cancel orders (স্টক ফেরত যাবে)")
    @transaction.atomic
    def cancel_orders(self, request, qs):
        for o in qs.exclude(status="cancelled"):
            for it in o.items.all():
                if it.product_id:
                    Product.objects.filter(pk=it.product_id).update(
                        stock=F("stock") + it.quantity, sold_count=F("sold_count") - it.quantity)
            o.status = "cancelled"
            o.save()


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "phone")
    search_fields = ("user__username", "phone")


admin.site.register(Wishlist)
