import logging
from decimal import Decimal

import requests
from django.conf import settings
from django.urls import reverse

log = logging.getLogger(__name__)


def _base():
    return "https://sandbox.sslcommerz.com" if settings.SSLCOMMERZ_SANDBOX else "https://securepay.sslcommerz.com"


def init_sslcommerz(request, order):
    """SSLCommerz সেশন তৈরি করে GatewayPageURL রিটার্ন করে (না পারলে None)।"""
    if not settings.SSLCOMMERZ_STORE_ID:
        return None
    build = request.build_absolute_uri
    data = {
        "store_id": settings.SSLCOMMERZ_STORE_ID,
        "store_passwd": settings.SSLCOMMERZ_STORE_PASSWORD,
        "total_amount": str(order.total),
        "currency": "BDT",
        "tran_id": order.order_number,
        "success_url": build(reverse("ssl_success")),
        "fail_url": build(reverse("ssl_fail")),
        "cancel_url": build(reverse("ssl_cancel")),
        "ipn_url": build(reverse("ssl_ipn")),
        "cus_name": order.name,
        "cus_email": order.email or "noemail@example.com",
        "cus_add1": order.address[:200],
        "cus_city": order.zone.name if order.zone else "Dhaka",
        "cus_country": "Bangladesh",
        "cus_phone": order.phone,
        "shipping_method": "NO",
        "num_of_item": order.items.count(),
        "product_name": "RH Shop Order",
        "product_category": "Fashion",
        "product_profile": "general",
    }
    try:
        r = requests.post(_base() + "/gwprocess/v4/api.php", data=data, timeout=30).json()
        return r.get("GatewayPageURL")
    except Exception as e:
        log.error("SSLCommerz init error: %s", e)
        return None


def validate_sslcommerz(val_id, order):
    try:
        r = requests.get(_base() + "/validator/api/validationserverAPI.php", params={
            "val_id": val_id,
            "store_id": settings.SSLCOMMERZ_STORE_ID,
            "store_passwd": settings.SSLCOMMERZ_STORE_PASSWORD,
            "format": "json",
        }, timeout=30).json()
        ok = r.get("status") in ("VALID", "VALIDATED")
        same = abs(Decimal(str(r.get("amount", "0"))) - order.total) < Decimal("1")
        return ok and same and r.get("tran_id") == order.order_number
    except Exception as e:
        log.error("SSLCommerz validate error: %s", e)
        return False
