from django.core.management.base import BaseCommand

from store.models import Category, Color, Coupon, DeliveryZone, Size


class Command(BaseCommand):
    help = "ডেমো ক্যাটাগরি, সাইজ, কালার, ডেলিভারি জোন ও কুপন তৈরি করে"

    def handle(self, *args, **opts):
        for n in ["টি-শার্ট", "প্যান্ট", "জুতা", "ড্রেস", "শার্ট"]:
            Category.objects.get_or_create(name=n)
        for s in ["S", "M", "L", "XL", "XXL", "38", "39", "40", "41", "42", "43"]:
            Size.objects.get_or_create(name=s)
        for n, h in [("Black", "#000000"), ("White", "#FFFFFF"), ("Red", "#DC3545"), ("Blue", "#0D6EFD"),
                     ("Green", "#198754"), ("Navy", "#001F3F")]:
            Color.objects.get_or_create(name=n, defaults={"hex_code": h})
        DeliveryZone.objects.get_or_create(name="ঢাকার ভিতরে", defaults={"charge": 60})
        DeliveryZone.objects.get_or_create(name="ঢাকার বাইরে", defaults={"charge": 120})
        Coupon.objects.get_or_create(code="WELCOME10", defaults={"discount_type": "percent", "value": 10, "min_order": 500})
        self.stdout.write(self.style.SUCCESS("ডেমো ডেটা তৈরি হয়েছে। এবার Admin থেকে পণ্য যোগ করুন।"))
