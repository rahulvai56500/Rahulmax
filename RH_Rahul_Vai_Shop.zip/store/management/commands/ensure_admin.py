import os
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "ENV ভ্যারিয়েবল থেকে সুপারইউজার তৈরি করে (না থাকলে)"

    def handle(self, *args, **opts):
        User = get_user_model()
        username = os.environ.get("ADMIN_USERNAME")
        password = os.environ.get("ADMIN_PASSWORD")
        if not username or not password:
            self.stdout.write("ADMIN_USERNAME/ADMIN_PASSWORD সেট নেই, স্কিপ করা হলো")
            return
        if User.objects.filter(username=username).exists():
            self.stdout.write("অ্যাডমিন আগে থেকেই আছে")
            return
        User.objects.create_superuser(username, os.environ.get("ADMIN_EMAIL", ""), password)
        self.stdout.write(self.style.SUCCESS(f"অ্যাডমিন '{username}' তৈরি হয়েছে"))
