from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, F, Q, Sum
from django.db.models.functions import TruncDate
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from .cart import Cart
from .forms import CheckoutForm, ProfileForm, RegisterForm
from .models import (Banner, Category, Coupon, DeliveryZone, Order, OrderItem, Product, Profile, Wishlist)
from .payments import init_sslcommerz, validate_sslcommerz


# ---------- Public pages ----------
def home(request):
    active = Product.objects.filter(is_active=True)
    ctx = {
        "banners": Banner.objects.filter(is_active=True, is_offer=False),
        "offers": Banner.objects.filter(is_active=True, is_offer=True)[:3],
        "new_arrivals": active.filter(is_new_arrival=True)[:8],
        "best_selling": active.filter(sold_count__gt=0).order_by("-sold_count")[:8],
        "featured": active.filter(is_featured=True)[:8],
        "on_sale": active.filter(discount_price__isnull=False)[:8],
        "categories": Category.objects.all(),
    }
    return render(request, "store/home.html", ctx)


def product_list(request):
    qs = Product.objects.filter(is_active=True).select_related("category")
    q = request.GET.get("q", "").strip()
    cat = request.GET.get("category", "")
    sort = request.GET.get("sort", "")
    pmin, pmax = request.GET.get("min", ""), request.GET.get("max", "")
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(description__icontains=q) | Q(category__name__icontains=q))
    if cat:
        qs = qs.filter(category__slug=cat)
    if pmin.isdigit():
        qs = qs.filter(price__gte=pmin)
    if pmax.isdigit():
        qs = qs.filter(price__lte=pmax)
    if request.GET.get("size"):
        qs = qs.filter(sizes__name=request.GET["size"])
    if request.GET.get("sale"):
        qs = qs.filter(discount_price__isnull=False)
    order = {"price_low": "price", "price_high": "-price", "new": "-created_at", "popular": "-sold_count"}.get(sort)
    if order:
        qs = qs.order_by(order)
    page = Paginator(qs.distinct(), 12).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    from .models import Size
    return render(request, "store/product_list.html", {
        "page": page, "q": q, "current_cat": cat, "sort": sort, "sizes": Size.objects.all(),
        "querystring": params.urlencode(), "pmin": pmin, "pmax": pmax,
    })


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    related = Product.objects.filter(category=product.category, is_active=True).exclude(pk=product.pk)[:4]
    in_wish = request.user.is_authenticated and Wishlist.objects.filter(user=request.user, product=product).exists()
    return render(request, "store/product_detail.html", {"product": product, "related": related, "in_wish": in_wish})


def robots_txt(request):
    body = "User-agent: *\nDisallow: /admin/\nDisallow: /cart/\nDisallow: /checkout/\n" \
           f"Sitemap: {request.build_absolute_uri('/sitemap.xml')}\n"
    return HttpResponse(body, content_type="text/plain")


# ---------- Cart ----------
def _read_item(request, product):
    size = request.POST.get("size", "")
    color = request.POST.get("color", "")
    try:
        qty = max(1, int(request.POST.get("qty", 1)))
    except ValueError:
        qty = 1
    return size, color, qty


def _needs_options(request, product, size, color):
    if product.sizes.exists() and not size:
        messages.error(request, "অনুগ্রহ করে সাইজ সিলেক্ট করুন")
        return True
    if product.colors.exists() and not color:
        messages.error(request, "অনুগ্রহ করে কালার সিলেক্ট করুন")
        return True
    return False


@require_POST
def add_to_cart(request, pid):
    product = get_object_or_404(Product, pk=pid, is_active=True)
    size, color, qty = _read_item(request, product)
    if _needs_options(request, product, size, color):
        return redirect(product)
    if product.stock <= 0:
        messages.error(request, "দুঃখিত, পণ্যটি স্টকে নেই")
        return redirect(product)
    Cart(request).add(product, qty, size, color)
    messages.success(request, f"'{product.name}' কার্টে যোগ হয়েছে")
    return redirect("cart")


@require_POST
def buy_now(request, pid):
    product = get_object_or_404(Product, pk=pid, is_active=True)
    size, color, qty = _read_item(request, product)
    if _needs_options(request, product, size, color):
        return redirect(product)
    if product.stock <= 0:
        messages.error(request, "দুঃখিত, পণ্যটি স্টকে নেই")
        return redirect(product)
    cart = Cart(request)
    cart.clear()
    cart.add(product, qty, size, color)
    return redirect("checkout")


def cart_view(request):
    cart = Cart(request)
    return render(request, "store/cart.html", {"items": cart.items(), "subtotal": cart.subtotal()})


@require_POST
def cart_update(request):
    cart = Cart(request)
    key = request.POST.get("key", "")
    if request.POST.get("action") == "remove":
        cart.remove(key)
    else:
        try:
            cart.update(key, int(request.POST.get("qty", 1)))
        except ValueError:
            pass
    return redirect("cart")


# ---------- Checkout ----------
def _apply_coupon(code, subtotal):
    if not code:
        return None, Decimal("0"), ""
    c = Coupon.objects.filter(code__iexact=code.strip()).first()
    if not c:
        return None, Decimal("0"), "কুপন কোড সঠিক নয়"
    ok, msg = c.check(subtotal)
    if not ok:
        return None, Decimal("0"), msg
    return c, c.amount(subtotal), ""


def checkout(request):
    cart = Cart(request)
    items = cart.items()
    if not items:
        messages.info(request, "আপনার কার্ট খালি")
        return redirect("product_list")
    subtotal = cart.subtotal()

    initial = {}
    if request.user.is_authenticated:
        p, _ = Profile.objects.get_or_create(user=request.user)
        initial = {"name": request.user.get_full_name() or request.user.username, "email": request.user.email,
                   "phone": p.phone, "address": p.address}
    form = CheckoutForm(request.POST or None, initial=initial)

    coupon, disc, cmsg = None, Decimal("0"), ""
    if request.method == "POST":
        coupon, disc, cmsg = _apply_coupon(request.POST.get("coupon_code", ""), subtotal)
        if cmsg:
            form.add_error("coupon_code", cmsg)

    if request.method == "POST" and request.POST.get("apply_coupon"):
        if coupon:
            messages.success(request, f"কুপন প্রযোজ্য: -৳{disc}")
        return render(request, "store/checkout.html", _checkout_ctx(form, items, subtotal, disc, request))

    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        with transaction.atomic():
            # স্টক লক করে চেক
            locked = Product.objects.select_for_update().in_bulk([i["product"].id for i in items])
            for i in items:
                p = locked[i["product"].id]
                if p.stock < i["qty"]:
                    messages.error(request, f"'{p.name}' এর স্টক পর্যাপ্ত নেই (আছে {p.stock}টি)")
                    return redirect("cart")
            zone = d["zone"]
            total = subtotal - disc + zone.charge
            pm = d["payment_method"]
            order = Order.objects.create(
                user=request.user if request.user.is_authenticated else None,
                name=d["name"], phone=d["phone"], email=d["email"], address=d["address"], zone=zone,
                subtotal=subtotal, discount=disc, delivery_charge=zone.charge, total=total, coupon=coupon,
                payment_method=pm, payment_status="pending" if pm in ("bkash", "nagad", "rocket") else "unpaid",
                sender_number=d["sender_number"], transaction_id=d["transaction_id"],
            )
            for i in items:
                p = locked[i["product"].id]
                OrderItem.objects.create(order=order, product=p, product_name=p.name, price=p.final_price,
                                         quantity=i["qty"], size=i["size"], color=i["color"])
                Product.objects.filter(pk=p.pk).update(stock=F("stock") - i["qty"], sold_count=F("sold_count") + i["qty"])
            if coupon:
                Coupon.objects.filter(pk=coupon.pk).update(used_count=F("used_count") + 1)
            if request.user.is_authenticated:
                Profile.objects.update_or_create(user=request.user, defaults={"phone": d["phone"], "address": d["address"]})
        cart.clear()
        if pm == "sslcommerz":
            url = init_sslcommerz(request, order)
            if url:
                return redirect(url)
            messages.error(request, "অনলাইন পেমেন্ট শুরু করা যায়নি। অর্ডারটি সংরক্ষিত আছে, আমাদের সাথে যোগাযোগ করুন।")
        return redirect("order_success", number=order.order_number)

    return render(request, "store/checkout.html", _checkout_ctx(form, items, subtotal, disc, request))


def _checkout_ctx(form, items, subtotal, disc, request):
    return {"form": form, "items": items, "subtotal": subtotal, "discount": disc,
            "zones": DeliveryZone.objects.filter(is_active=True),
            "bkash": settings.BKASH_NUMBER, "nagad": settings.NAGAD_NUMBER, "rocket": settings.ROCKET_NUMBER,
            "ssl_enabled": bool(settings.SSLCOMMERZ_STORE_ID)}


def order_success(request, number):
    order = get_object_or_404(Order, order_number=number)
    return render(request, "store/order_success.html", {"order": order})


def order_track(request, number):
    order = get_object_or_404(Order, order_number=number)
    steps = ["pending", "processing", "shipped", "delivered"]
    idx = steps.index(order.status) if order.status in steps else -1
    return render(request, "store/order_track.html", {"order": order, "steps": steps, "idx": idx})


def track_lookup(request):
    if request.method == "POST":
        num = request.POST.get("order_number", "").strip().upper()
        if Order.objects.filter(order_number=num).exists():
            return redirect("order_track", number=num)
        messages.error(request, "এই নাম্বারে কোনো অর্ডার পাওয়া যায়নি")
    return render(request, "store/track_lookup.html")


# ---------- SSLCommerz callbacks ----------
@csrf_exempt
def ssl_success(request):
    order = Order.objects.filter(order_number=request.POST.get("tran_id", "")).first()
    if not order:
        return redirect("home")
    if validate_sslcommerz(request.POST.get("val_id", ""), order):
        order.payment_status = "paid"
        order.transaction_id = request.POST.get("bank_tran_id", "")[:60]
        order.save()
    else:
        order.payment_status = "failed"
        order.save()
    return redirect("order_success", number=order.order_number)


@csrf_exempt
def ssl_fail(request):
    order = Order.objects.filter(order_number=request.POST.get("tran_id", "")).first()
    if order:
        order.payment_status = "failed"
        order.save()
        messages.error(request, "পেমেন্ট ব্যর্থ হয়েছে")
        return redirect("order_success", number=order.order_number)
    return redirect("home")


@csrf_exempt
def ssl_cancel(request):
    return ssl_fail(request)


@csrf_exempt
def ssl_ipn(request):
    order = Order.objects.filter(order_number=request.POST.get("tran_id", "")).first()
    if order and order.payment_status != "paid" and validate_sslcommerz(request.POST.get("val_id", ""), order):
        order.payment_status = "paid"
        order.save()
    return HttpResponse("OK")


# ---------- Accounts ----------
def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "রেজিস্ট্রেশন সফল হয়েছে, স্বাগতম!")
        return redirect("home")
    return render(request, "registration/register.html", {"form": form})


@login_required
def profile(request):
    p, _ = Profile.objects.get_or_create(user=request.user)
    u = request.user
    form = ProfileForm(request.POST or None, initial={
        "first_name": u.first_name, "last_name": u.last_name, "email": u.email,
        "phone": p.phone, "address": p.address})
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        u.first_name, u.last_name, u.email = d["first_name"], d["last_name"], d["email"]
        u.save()
        p.phone, p.address = d["phone"], d["address"]
        p.save()
        messages.success(request, "প্রোফাইল আপডেট হয়েছে")
        return redirect("profile")
    return render(request, "store/profile.html", {"form": form})


@login_required
def my_orders(request):
    return render(request, "store/my_orders.html", {"orders": request.user.orders.prefetch_related("items")})


@login_required
def wishlist(request):
    return render(request, "store/wishlist.html", {"items": request.user.wishlist.select_related("product")})


@login_required
@require_POST
def wishlist_toggle(request, pid):
    product = get_object_or_404(Product, pk=pid)
    obj, created = Wishlist.objects.get_or_create(user=request.user, product=product)
    if not created:
        obj.delete()
        messages.info(request, "উইশলিস্ট থেকে সরানো হয়েছে")
    else:
        messages.success(request, "উইশলিস্টে যোগ হয়েছে")
    return redirect(request.POST.get("next") or product.get_absolute_url())


# ---------- Staff dashboard ----------
@staff_member_required
def dashboard(request):
    valid = Order.objects.exclude(status="cancelled")
    today = timezone.localdate()
    since = timezone.now() - timedelta(days=30)
    income = Order.objects.filter(payment_status="paid").aggregate(s=Sum("total"))["s"] or 0
    daily = (valid.filter(created_at__gte=since).annotate(day=TruncDate("created_at"))
             .values("day").annotate(total=Sum("total"), n=Count("id")).order_by("-day")[:30])
    top = (OrderItem.objects.exclude(order__status="cancelled").values("product_name")
           .annotate(q=Sum("quantity")).order_by("-q")[:5])
    ctx = {
        "total_sales": valid.aggregate(s=Sum("total"))["s"] or 0,
        "total_income": income,
        "today_sales": valid.filter(created_at__date=today).aggregate(s=Sum("total"))["s"] or 0,
        "order_count": Order.objects.count(),
        "status_counts": {k: Order.objects.filter(status=k).count() for k, _ in Order.STATUS},
        "pending_payments": Order.objects.filter(payment_status="pending").count(),
        "customers": Order.objects.values("phone").distinct().count(),
        "products": Product.objects.count(),
        "low_stock": Product.objects.filter(stock__lte=5, is_active=True).order_by("stock")[:10],
        "recent": Order.objects.all()[:10],
        "daily": daily, "top": top,
    }
    return render(request, "dashboard/dashboard.html", ctx)
