from django.conf import settings
from .cart import Cart
from .models import Category


def site_context(request):
    wish = 0
    if request.user.is_authenticated:
        wish = request.user.wishlist.count()
    return {
        "SHOP_NAME": settings.SHOP_NAME,
        "nav_categories": Category.objects.all(),
        "cart_count": Cart(request).count(),
        "wishlist_count": wish,
    }
