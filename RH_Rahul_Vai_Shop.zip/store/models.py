import uuid
from decimal import Decimal

from django.conf import settings
from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify


def unique_slug(instance, source, model):
    base = slugify(source, allow_unicode=True) or "item"
    slug, n = base, 1
    qs = model.objects.exclude(pk=instance.pk)
    while qs.filter(slug=slug).exists():
        n += 1
        slug = f"{base}-{n}"
    return slug


def optimize_image(field, max_size=1000):
    """আপলোড করা ছবি ছোট ও দ্রুত লোডযোগ্য করে।"""
    try:
        from PIL import Image
        if not field:
            return
        path = field.path
        img = Image.open(path)
        if img.width > max_size or img.height > max_size:
            img.thumbnail((max_size, max_size))
        fmt = (img.format or "JPEG").upper()
        if fmt == "JPEG":
            img = img.convert("RGB")
            img.save(path, "JPEG", quality=82, optimize=True)
        elif fmt == "PNG":
            img.save(path, "PNG", optimize=True)
        else:
            img.save(path)
    except Exception:
        pass


class Category(models.Model):
    name = models.CharField("ক্যাটাগরি নাম", max_length=100)
    slug = models.SlugField(unique=True, blank=True, allow_unicode=True)
    image = models.ImageField(upload_to="categories/", blank=True, null=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["name"]

    def save(self, *a, **k):
        if not self.slug:
            self.slug = unique_slug(self, self.name, Category)
        super().save(*a, **k)

    def get_absolute_url(self):
        return reverse("product_list") + f"?category={self.slug}"

    def __str__(self):
        return self.name


class Size(models.Model):
    name = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return self.name


class Color(models.Model):
    name = models.CharField(max_length=30, unique=True)
    hex_code = models.CharField(max_length=7, default="#000000", help_text="যেমন #FF0000")

    def __str__(self):
        return self.name


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    name = models.CharField("পণ্যের নাম", max_length=200)
    slug = models.SlugField(unique=True, blank=True, allow_unicode=True, max_length=220)
    description = models.TextField("বিবরণ", blank=True)
    price = models.DecimalField("মূল্য (৳)", max_digits=10, decimal_places=2)
    discount_price = models.DecimalField("ডিসকাউন্ট মূল্য (৳)", max_digits=10, decimal_places=2, blank=True, null=True,
                                         help_text="খালি রাখলে ডিসকাউন্ট থাকবে না")
    image = models.ImageField("মূল ছবি", upload_to="products/")
    sizes = models.ManyToManyField(Size, blank=True)
    colors = models.ManyToManyField(Color, blank=True)
    stock = models.PositiveIntegerField("স্টক", default=0)
    is_active = models.BooleanField("সক্রিয়", default=True)
    is_new_arrival = models.BooleanField("New Arrival", default=True)
    is_featured = models.BooleanField("Featured", default=False)
    sold_count = models.PositiveIntegerField("বিক্রি হয়েছে", default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *a, **k):
        if not self.slug:
            self.slug = unique_slug(self, self.name, Product)
        super().save(*a, **k)
        optimize_image(self.image)

    @property
    def final_price(self):
        if self.discount_price and self.discount_price < self.price:
            return self.discount_price
        return self.price

    @property
    def has_discount(self):
        return bool(self.discount_price and self.discount_price < self.price)

    @property
    def discount_percent(self):
        if self.has_discount:
            return int((self.price - self.discount_price) / self.price * 100)
        return 0

    def get_absolute_url(self):
        return reverse("product_detail", args=[self.slug])

    def __str__(self):
        return self.name


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="gallery")
    image = models.ImageField(upload_to="products/gallery/")

    def save(self, *a, **k):
        super().save(*a, **k)
        optimize_image(self.image)


class Banner(models.Model):
    title = models.CharField(max_length=120)
    subtitle = models.CharField(max_length=200, blank=True)
    image = models.ImageField(upload_to="banners/")
    link = models.CharField(max_length=300, blank=True, help_text="যেমন /products/?category=t-shirt")
    is_offer = models.BooleanField("Offer Section এ দেখাবে", default=False)
    is_active = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def save(self, *a, **k):
        super().save(*a, **k)
        optimize_image(self.image, 1600)

    def __str__(self):
        return self.title


class Coupon(models.Model):
    PERCENT, FIXED = "percent", "fixed"
    code = models.CharField(max_length=30, unique=True)
    discount_type = models.CharField(max_length=10, choices=[(PERCENT, "Percent %"), (FIXED, "Fixed ৳")], default=PERCENT)
    value = models.DecimalField(max_digits=8, decimal_places=2)
    min_order = models.DecimalField("সর্বনিম্ন অর্ডার", max_digits=10, decimal_places=2, default=0)
    valid_to = models.DateTimeField(blank=True, null=True)
    usage_limit = models.PositiveIntegerField(default=0, help_text="0 = আনলিমিটেড")
    used_count = models.PositiveIntegerField(default=0, editable=False)
    is_active = models.BooleanField(default=True)

    def check(self, subtotal):
        """(valid, message)"""
        if not self.is_active:
            return False, "এই কুপন সক্রিয় নয়"
        if self.valid_to and self.valid_to < timezone.now():
            return False, "কুপনের মেয়াদ শেষ"
        if self.usage_limit and self.used_count >= self.usage_limit:
            return False, "কুপনের ব্যবহার সীমা শেষ"
        if subtotal < self.min_order:
            return False, f"সর্বনিম্ন অর্ডার ৳{self.min_order} হতে হবে"
        return True, ""

    def amount(self, subtotal):
        if self.discount_type == self.PERCENT:
            return (subtotal * self.value / Decimal("100")).quantize(Decimal("0.01"))
        return min(self.value, subtotal)

    def __str__(self):
        return self.code


class DeliveryZone(models.Model):
    name = models.CharField("এলাকা", max_length=100)
    charge = models.DecimalField("ডেলিভারি চার্জ (৳)", max_digits=8, decimal_places=2)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} (৳{self.charge})"


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)

    def __str__(self):
        return self.user.username


class Order(models.Model):
    STATUS = [("pending", "Pending"), ("processing", "Processing"), ("shipped", "Shipped"),
              ("delivered", "Delivered"), ("cancelled", "Cancelled")]
    PAY_STATUS = [("unpaid", "Unpaid"), ("pending", "Verification Pending"), ("paid", "Paid"), ("failed", "Failed")]
    PAY_METHOD = [("cod", "Cash on Delivery"), ("bkash", "bKash"), ("nagad", "Nagad"),
                  ("rocket", "Rocket"), ("sslcommerz", "SSLCommerz (Card/Bank)")]

    order_number = models.CharField(max_length=20, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="orders")
    name = models.CharField(max_length=120)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    address = models.TextField()
    zone = models.ForeignKey(DeliveryZone, on_delete=models.SET_NULL, null=True, blank=True)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    delivery_charge = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    coupon = models.ForeignKey(Coupon, on_delete=models.SET_NULL, null=True, blank=True)
    payment_method = models.CharField(max_length=15, choices=PAY_METHOD, default="cod")
    payment_status = models.CharField(max_length=10, choices=PAY_STATUS, default="unpaid")
    sender_number = models.CharField("Sender Number", max_length=20, blank=True)
    transaction_id = models.CharField("TrxID", max_length=60, blank=True)
    status = models.CharField(max_length=12, choices=STATUS, default="pending")
    tracking_note = models.CharField("Tracking/Courier Note", max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *a, **k):
        if not self.order_number:
            self.order_number = "RH" + uuid.uuid4().hex[:8].upper()
        super().save(*a, **k)

    def get_absolute_url(self):
        return reverse("order_track", args=[self.order_number])

    def __str__(self):
        return self.order_number


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    product_name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)
    size = models.CharField(max_length=20, blank=True)
    color = models.CharField(max_length=30, blank=True)

    @property
    def total(self):
        return self.price * self.quantity


class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="wishlist")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "product")
        ordering = ["-created_at"]
