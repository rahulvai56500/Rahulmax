from datetime import datetime

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "ডাটাবেসের JSON ব্যাকআপ তৈরি করে (BACKUP_DIR এ)"

    def handle(self, *args, **opts):
        settings.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        path = settings.BACKUP_DIR / f"backup_{datetime.now():%Y%m%d_%H%M%S}.json"
        with open(path, "w", encoding="utf-8") as f:
            call_command("dumpdata", "--exclude", "contenttypes", "--exclude", "sessions",
                         "--exclude", "admin.logentry", "--indent", "1", stdout=f)
        self.stdout.write(self.style.SUCCESS(f"ব্যাকআপ তৈরি: {path}"))
