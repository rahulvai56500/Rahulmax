from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import DeliveryZone, Order, Profile


class BootstrapMixin:
    def _style(self):
        for f in self.fields.values():
            w = f.widget
            if isinstance(w, forms.Select):
                w.attrs["class"] = "form-select"
            elif isinstance(w, (forms.CheckboxInput, forms.RadioSelect)):
                pass
            else:
                w.attrs["class"] = "form-control"


class RegisterForm(BootstrapMixin, UserCreationForm):
    first_name = forms.CharField(label="আপনার নাম", max_length=60)
    email = forms.EmailField(label="Email")
    phone = forms.CharField(label="মোবাইল নাম্বার", max_length=20)

    class Meta:
        model = User
        fields = ("username", "first_name", "email", "phone", "password1", "password2")

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self._style()

    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            Profile.objects.update_or_create(user=user, defaults={"phone": self.cleaned_data["phone"]})
        return user


class ProfileForm(BootstrapMixin, forms.Form):
    first_name = forms.CharField(label="নাম", max_length=60)
    last_name = forms.CharField(label="শেষ নাম", max_length=60, required=False)
    email = forms.EmailField(label="Email")
    phone = forms.CharField(label="মোবাইল", max_length=20, required=False)
    address = forms.CharField(label="ঠিকানা", required=False, widget=forms.Textarea(attrs={"rows": 3}))

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self._style()


class CheckoutForm(BootstrapMixin, forms.Form):
    name = forms.CharField(label="আপনার নাম", max_length=120)
    phone = forms.RegexField(label="মোবাইল নাম্বার", regex=r"^(\+?88)?01[3-9]\d{8}$",
                             error_messages={"invalid": "সঠিক বাংলাদেশি মোবাইল নাম্বার দিন"})
    email = forms.EmailField(label="Email (ঐচ্ছিক)", required=False)
    address = forms.CharField(label="সম্পূর্ণ ঠিকানা", widget=forms.Textarea(attrs={"rows": 3}))
    zone = forms.ModelChoiceField(label="ডেলিভারি এলাকা", queryset=DeliveryZone.objects.none(), empty_label=None)
    payment_method = forms.ChoiceField(label="পেমেন্ট মাধ্যম", choices=Order.PAY_METHOD, widget=forms.RadioSelect,
                                       initial="cod")
    sender_number = forms.CharField(label="যে নাম্বার থেকে টাকা পাঠিয়েছেন", required=False, max_length=20)
    transaction_id = forms.CharField(label="Transaction ID (TrxID)", required=False, max_length=60)
    coupon_code = forms.CharField(label="কুপন কোড", required=False, max_length=30)

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.fields["zone"].queryset = DeliveryZone.objects.filter(is_active=True)
        self._style()

    def clean(self):
        d = super().clean()
        if d.get("payment_method") in ("bkash", "nagad", "rocket"):
            if not d.get("transaction_id"):
                self.add_error("transaction_id", "Mobile Banking এ পেমেন্ট করলে TrxID দিতে হবে")
        return d
