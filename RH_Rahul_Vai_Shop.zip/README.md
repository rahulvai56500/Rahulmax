# RH Rahul Vai Shop – Django E-commerce

Django + PostgreSQL + Bootstrap। Railway-তে ডিপ্লয়ের জন্য প্রস্তুত।

## ফিচার
পণ্য/ক্যাটাগরি/সাইজ/কালার/স্টক, সার্চ-ফিল্টার-সর্ট, Cart, Buy Now, Checkout, কুপন, ডেলিভারি চার্জ (এলাকাভিত্তিক),
COD, bKash/Nagad/Rocket (TrxID দিয়ে, অ্যাডমিন ভেরিফাই করবে), SSLCommerz, রেজিস্ট্রেশন/লগইন/প্রোফাইল/পাসওয়ার্ড পরিবর্তন,
অর্ডার হিস্ট্রি ও ট্র্যাকিং, Wishlist, Admin Panel + Sales/Income Dashboard, SEO (sitemap, robots), ছবি অপটিমাইজেশন, ব্যাকআপ কমান্ড।

## Railway-তে ডিপ্লয় (ধাপে ধাপে)

1. **GitHub এ আপলোড:** এই ফোল্ডারের সব ফাইল একটি নতুন GitHub রিপোজিটরিতে আপলোড করুন।
2. **Railway:** railway.app → New Project → Deploy from GitHub repo → আপনার রিপো সিলেক্ট করুন।
3. **ডাটাবেস:** প্রজেক্টে + New → Database → Add PostgreSQL।
4. **ওয়েব সার্ভিসে Variables** (Variables ট্যাব):
   - `DATABASE_URL` = `${{Postgres.DATABASE_URL}}`  (Reference হিসেবে যোগ করুন)
   - `SECRET_KEY` = একটি লম্বা র‍্যান্ডম স্ট্রিং
   - `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ADMIN_EMAIL` (প্রথম ডিপ্লয়ে অ্যাডমিন অটো তৈরি হবে)
   - `BKASH_NUMBER`, `NAGAD_NUMBER`, `ROCKET_NUMBER` (যেগুলো ব্যবহার করবেন)
   - SSLCommerz ব্যবহার করলে: `SSLCOMMERZ_STORE_ID`, `SSLCOMMERZ_STORE_PASSWORD`, `SSLCOMMERZ_SANDBOX=False` (লাইভে)
5. **ছবি স্থায়ী রাখতে (খুব জরুরি):** সার্ভিসে Volume যোগ করুন, Mount path `/data`। তারপর Variables এ
   `MEDIA_ROOT=/data/media` ও `BACKUP_DIR=/data/backups` দিন। Volume ছাড়া রিডিপ্লয়ে আপলোড করা ছবি মুছে যাবে।
6. **Domain:** Settings → Networking → Generate Domain (বা Custom Domain যোগ করে DNS এ CNAME বসান)।
   Custom domain হলে `ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com` ও
   `CSRF_TRUSTED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com` দিন। HTTPS অটো পাবেন।
7. **প্রথমবার চালু হলে:** `https://আপনার-ডোমেইন/admin/` এ লগইন করুন।
   ডেমো ক্যাটাগরি/সাইজ/কালার/ডেলিভারি জোন তৈরি করতে Railway CLI বা Shell থেকে: `python manage.py seed_demo`
   (অথবা Admin Panel থেকে নিজে যোগ করুন – Delivery Zone অবশ্যই যোগ করতে হবে, নইলে Checkout চলবে না)।

## ⚠️ গুরুত্বপূর্ণ: Migration ফাইল
প্রথমে লোকাল কম্পিউটারে একবার `python manage.py makemigrations store` চালিয়ে `store/migrations/0001_initial.py` তৈরি করে
GitHub এ আপলোড করুন। ভবিষ্যতে মডেল বদলালে একইভাবে নতুন migration আপলোড করবেন।

## লোকাল টেস্ট
```
python -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
set DEBUG=True        # Linux/Mac: export DEBUG=True
python manage.py makemigrations store
python manage.py migrate
python manage.py createsuperuser
python manage.py seed_demo
python manage.py runserver
```

## দৈনন্দিন ব্যবহার
- **Admin Panel (/admin/):** পণ্য যোগ/এডিট/ডিলিট, দাম ও স্টক সরাসরি লিস্ট থেকে বদলানো, অর্ডার স্ট্যাটাস
  (Pending → Processing → Shipped → Delivered), কুপন, ব্যানার, ডেলিভারি চার্জ।
- **Dashboard (/dashboard/):** মোট বিক্রি, আয়, দৈনিক রিপোর্ট, কম স্টক, সর্বাধিক বিক্রিত পণ্য।
- **মোবাইল ব্যাংকিং অর্ডার:** Admin → Orders এ TrxID মিলিয়ে `Payment Status` কে Paid করুন।
- **ব্যাকআপ:** `python manage.py backup_db` (JSON ব্যাকআপ `BACKUP_DIR` এ)। এছাড়া Railway PostgreSQL এর নিজস্ব ব্যাকআপও চালু রাখুন।

## নোট
- bKash/Nagad/Rocket এখানে "Send Money + TrxID" পদ্ধতিতে কাজ করে। অটো-পেমেন্ট API চাইলে merchant অ্যাকাউন্ট নিয়ে আলাদা ইন্টিগ্রেশন লাগবে।
- SSLCommerz এর জন্য sandbox এ টেস্ট করে তারপর `SSLCOMMERZ_SANDBOX=False` করুন।
