from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("products/", views.product_list, name="product_list"),
    path("product/<slug:slug>/", views.product_detail, name="product_detail"),
    path("cart/", views.cart_view, name="cart"),
    path("cart/add/<int:pid>/", views.add_to_cart, name="add_to_cart"),
    path("cart/buy-now/<int:pid>/", views.buy_now, name="buy_now"),
    path("cart/update/", views.cart_update, name="cart_update"),
    path("checkout/", views.checkout, name="checkout"),
    path("order/success/<str:number>/", views.order_success, name="order_success"),
    path("track/", views.track_lookup, name="track_lookup"),
    path("track/<str:number>/", views.order_track, name="order_track"),
    path("payment/ssl/success/", views.ssl_success, name="ssl_success"),
    path("payment/ssl/fail/", views.ssl_fail, name="ssl_fail"),
    path("payment/ssl/cancel/", views.ssl_cancel, name="ssl_cancel"),
    path("payment/ssl/ipn/", views.ssl_ipn, name="ssl_ipn"),
    path("register/", views.register, name="register"),
    path("profile/", views.profile, name="profile"),
    path("my-orders/", views.my_orders, name="my_orders"),
    path("wishlist/", views.wishlist, name="wishlist"),
    path("wishlist/toggle/<int:pid>/", views.wishlist_toggle, name="wishlist_toggle"),
    path("dashboard/", views.dashboard, name="dashboard"),
]
