from decimal import Decimal
from .models import Product


class Cart:
    KEY = "cart"

    def __init__(self, request):
        self.session = request.session
        self.data = self.session.setdefault(self.KEY, {})

    def _save(self):
        self.session.modified = True

    @staticmethod
    def make_key(pid, size, color):
        return f"{pid}|{size}|{color}"

    def add(self, product, qty=1, size="", color="", replace=False):
        key = self.make_key(product.id, size, color)
        cur = 0 if replace else self.data.get(key, {}).get("qty", 0)
        new = min(cur + qty, product.stock)
        if new > 0:
            self.data[key] = {"pid": product.id, "qty": new, "size": size, "color": color}
        self._save()

    def update(self, key, qty):
        if key in self.data:
            if qty <= 0:
                del self.data[key]
            else:
                p = Product.objects.filter(id=self.data[key]["pid"]).first()
                self.data[key]["qty"] = min(qty, p.stock) if p else qty
            self._save()

    def remove(self, key):
        self.data.pop(key, None)
        self._save()

    def clear(self):
        self.session[self.KEY] = {}
        self._save()

    def items(self):
        products = Product.objects.in_bulk([v["pid"] for v in self.data.values()])
        out = []
        for key, v in self.data.items():
            p = products.get(v["pid"])
            if not p or not p.is_active:
                continue
            out.append({"key": key, "product": p, "qty": v["qty"], "size": v["size"],
                        "color": v["color"], "total": p.final_price * v["qty"]})
        return out

    def subtotal(self):
        return sum((i["total"] for i in self.items()), Decimal("0"))

    def count(self):
        return sum(v["qty"] for v in self.data.values())
